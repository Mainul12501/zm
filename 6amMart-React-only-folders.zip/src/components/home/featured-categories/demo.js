import ex from "./assets/example.png";

export const demoData = [
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
    {
        icon: ex,
        title: "something",
    },
];